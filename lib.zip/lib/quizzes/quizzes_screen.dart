import "package:flutter/material.dart";
import 'add_quiz/quiz_add_screen.dart';
import 'add_quiz/quiz_num.dart';

class QuizScreen extends StatelessWidget {
  const QuizScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text("Quizler")),
      ),
      body: Container(
          child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
        child: Column(
          children: const [
            QuizCard(),
            QuizCard(),
          ],
        ),
      )),
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(bottom: 30),
        child: FloatingActionButton(
          backgroundColor: Color.fromARGB(255, 146, 196, 238),
          onPressed: () {
            Navigator.of(context)
                .push(MaterialPageRoute(builder: (context) => const QuizNum()));
          },
          child: const Icon(Icons.add_box),
        ),
      ),
    );
  }
}

class QuizCard extends StatelessWidget {
  const QuizCard({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10),
      child: Card(
        color: Color.fromARGB(255, 146, 196, 238),
        elevation: 4,
        shadowColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 5, 0, 0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "Quiz Başlığı",
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      color: Colors.black87, fontWeight: FontWeight.w600),
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 15, horizontal: 15),
              child: Align(
                child: Text(
                  "Quiz katalog",
                  style: TextStyle(
                      color: Colors.black87, fontWeight: FontWeight.w500),
                ),
                alignment: Alignment.centerLeft,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
